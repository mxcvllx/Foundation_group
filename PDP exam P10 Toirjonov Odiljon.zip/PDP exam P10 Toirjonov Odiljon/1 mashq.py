""""""
"""
1. “Although that way may not be obvious at first unless you're
Dutch.” berilgan string da “a” harfi kelsa ularning indeksini
alohida list da qaytaring.
"""

a = list("Although that way may not be obvious at first unless you're Dutch.")
d = []
for i in a:
    if i == 'a':
        d.append(i)
print(d)
