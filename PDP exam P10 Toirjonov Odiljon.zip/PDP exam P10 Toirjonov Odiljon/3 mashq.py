""""""
"""
3. add_tags nomli funksiya yarating bunda funksiya 2 ta argunment
tag va string qabul qiladi. Natijani html tag sifatida
qaytaring.
add_tags(“b”, “Hello, Python”) -> “<b>Hello, Python</b>”
add_tags(“h1”, “Hello, Python”) -> “<h1>Hello, Python</h1>
”"""


def add_tags(tag, word):
    return "<%s>%s</%s>" % (tag, word, tag)


print(add_tags("b", "Hello, Python"))
print(add_tags("h1", "Hello, Python"))
