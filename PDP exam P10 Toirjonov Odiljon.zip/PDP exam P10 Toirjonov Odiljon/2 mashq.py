""""""
"""
2. lst = ['apple', 'banana', 'peach', 42] listda string tipidagi
har bir elemetlar yonidan oxiridagi raqamni birga qaytaring.
Output: “Apple 42, Banana 42, Peach 42
”"""

lst = ['apple', 'banana', 'peach', 42]
r = lst.pop(-1)
for i in lst:
    print(i, r)
