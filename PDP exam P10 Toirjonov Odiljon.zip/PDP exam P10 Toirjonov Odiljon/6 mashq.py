people = [
    {
        'name': 'Foo Bar',
        'email': 'foo@example.com'
    },
    {
        'name': 'Qux Bar',
        'email': 'qux@example.com',
        'address': 'Borg, Country',
        'children': ['Alpha', 'Beta']
    }
]

