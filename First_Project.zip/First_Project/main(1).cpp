#include <iostream>

using namespace std;

int main()
{

/*  cout<<  "******"<< endl;
    cout<<  "*****"<< endl;
    cout<<  "****"<< endl;
    cout<<  "***"<< endl;
    cout<<  "**"<< endl;
    cout<<  "*"<< endl;
*/
/*
    cout << "******" << endl;
    cout << "*   *" << endl;
    cout << "*  *" << endl;
    cout << "* *" << endl;
    cout << "**" << endl;
    cout << "*" << endl;
*/
/*
    cout <<"      *" << endl;
    cout <<"     * *" << endl;
    cout <<"    *   *" << endl;
    cout <<"   *     *" << endl;
    cout <<"  *       *"<< endl;
    cout <<" * * * * * *" << endl;
*/

/*

     cout <<" ***********" << endl;
     cout <<"  *********" << endl;
     cout <<"   *******" << endl;
     cout <<"    *****" << endl;
     cout <<"     ***" << endl;
     cout <<"      *" << endl;

*/
/*
     cout << "        1" << endl;
     cout << "       1 2" << endl;
     cout << "      1 2 3" << endl;
     cout << "     1 2 3 4" << endl;
     cout << "    1 2 3 4 5" << endl;
     cout << "   1 2 3 4 5 6" << endl;
     cout << "  1 2 3 4 5 6 7" << endl;
     cout << " 1 2 3 4 5 6 7 8" << endl;
     cout << "1 2 3 4 5 6 7 8 9" << endl;
     cout << " 1 2 3 4 5 6 7 8" << endl;
     cout << "  1 2 3 4 5 6 7" << endl;
     cout << "   1 2 3 4 5 6" << endl;
     cout << "    1 2 3 4 5" << endl;
     cout << "     1 2 3 4" << endl;
     cout << "      1 2 3" << endl;
     cout << "       1 2" << endl;
     cout << "        1" << endl;
*/
/*

     cout << "1        1" << endl;
     cout << "12      21" << endl;
     cout << "123    321"  << endl;
     cout << "1234  4321" << endl;
     cout << "1234554321" << endl;
*/
/*
     cout <<"     1"<<endl;
     cout <<"   232"<<endl;
     cout <<" 34543"<<endl;
*/
/*
     cout <<"      *" << endl;
     cout <<"     *-*" << endl;
     cout <<"    *---*" << endl;
     cout <<"   *-----*" << endl;
     cout <<"  *-------*" << endl;
     cout <<" *---------*" << endl;
     cout <<" *+++++++++*" << endl;
     cout <<"  *+++++++*" << endl;
     cout <<"   *+++++*" << endl;
     cout <<"    *+++*" << endl;
     cout <<"     *+*" << endl;
     cout <<"      *" << endl;



*/





string str;
int som;
char xz;
bool tr;
double onlison;



//str = "bye bye world";
//cout << str;

//som = 76;
//cout << som;

//xz = '?';
//cout << xz;

//tr = true
//cout << tr;

//onlison = 10.23;
//cout << onlison;

/*
int number;
number = 14;


int son = 10;


cin >> son;

cout << son << " * 2 = "     << son *2 <<"\n";
cout << son << " * 3 = "     << son *3 <<"\n";
cout << son << " * 4 = "     << son *4 <<"\n";
cout << son << " * 5 = "     << son *5 <<"\n";
cout << son << " * 6 = "     << son *6 <<"\n";
cout << son << " * 7 = "     << son *7 <<"\n";
cout << son << " * 8 = "     << son *8 <<"\n";
cout << son << " * 9 = "     << son *9 <<"\n";
cout << son << " * 10 = "     << son *10 <<"\n";

*/

int yosh;


cin >> yosh;

cout << 2022 -yosh << "\n" ;











          return 0;

}















