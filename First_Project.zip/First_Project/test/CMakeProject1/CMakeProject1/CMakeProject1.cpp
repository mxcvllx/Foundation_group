﻿// CMakeProject1.cpp: определяет точку входа для приложения.
//

#include "CMakeProject1.h"

using namespace std;

int main()
{
	cout << "Hello CMake." << endl;
	return 0;
}
