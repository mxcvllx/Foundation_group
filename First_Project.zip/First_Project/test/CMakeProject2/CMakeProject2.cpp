﻿#include <iostream>
#include <string>
using namespace std;

int swapp(int a, int b);

int main()
{

    int a(2);
    int b(5);
    cout << a << endl;
    cout << b << endl;
    swapp(a, b);

}


int sortInc(a, b, c)

