#include <iostream>

using namespace std;

void salom (string ism){
cout << "Salom" << ism << endl;

}

int main()
{

string a;
cin >> a;
salom(a);
    return 0;
}
