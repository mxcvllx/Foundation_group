#include <iostream>
#include <cmath>

using namespace std;

int main()
{

/*  cout<<  "******"<< endl;
    cout<<  "*****"<< endl;
    cout<<  "****"<< endl;
    cout<<  "***"<< endl;
    cout<<  "**"<< endl;
    cout<<  "*"<< endl;
*/
/*
    cout << "******" << endl;
    cout << "*   *" << endl;
    cout << "*  *" << endl;
    cout << "* *" << endl;
    cout << "**" << endl;
    cout << "*" << endl;
*/
/*
    cout <<"      *" << endl;
    cout <<"     * *" << endl;
    cout <<"    *   *" << endl;
    cout <<"   *     *" << endl;
    cout <<"  *       *"<< endl;
    cout <<" * * * * * *" << endl;
*/

/*

     cout <<" ***********" << endl;
     cout <<"  *********" << endl;
     cout <<"   *******" << endl;
     cout <<"    *****" << endl;
     cout <<"     ***" << endl;
     cout <<"      *" << endl;

*/
/*
     cout << "        1" << endl;
     cout << "       1 2" << endl;
     cout << "      1 2 3" << endl;
     cout << "     1 2 3 4" << endl;
     cout << "    1 2 3 4 5" << endl;
     cout << "   1 2 3 4 5 6" << endl;
     cout << "  1 2 3 4 5 6 7" << endl;
     cout << " 1 2 3 4 5 6 7 8" << endl;
     cout << "1 2 3 4 5 6 7 8 9" << endl;
     cout << " 1 2 3 4 5 6 7 8" << endl;
     cout << "  1 2 3 4 5 6 7" << endl;
     cout << "   1 2 3 4 5 6" << endl;
     cout << "    1 2 3 4 5" << endl;
     cout << "     1 2 3 4" << endl;
     cout << "      1 2 3" << endl;
     cout << "       1 2" << endl;
     cout << "        1" << endl;
*/
/*

     cout << "1        1" << endl;
     cout << "12      21" << endl;
     cout << "123    321"  << endl;
     cout << "1234  4321" << endl;
     cout << "1234554321" << endl;
*/
/*
     cout <<"     1"<<endl;
     cout <<"   232"<<endl;
     cout <<" 34543"<<endl;
*/
/*
     cout <<"      *" << endl;
     cout <<"     *-*" << endl;
     cout <<"    *---*" << endl;
     cout <<"   *-----*" << endl;
     cout <<"  *-------*" << endl;
     cout <<" *---------*" << endl;
     cout <<" *+++++++++*" << endl;
     cout <<"  *+++++++*" << endl;
     cout <<"   *+++++*" << endl;
     cout <<"    *+++*" << endl;
     cout <<"     *+*" << endl;
     cout <<"      *" << endl;



*/



/*

string str;
int som;
char xz;
bool tr;
double onlison;

*/

//str = "bye bye world";
//cout << str;

//som = 76;
//cout << som;

//xz = '?';
//cout << xz;

//tr = true
//cout << tr;

//onlison = 10.23;
//cout << onlison;

/*
int number;
number = 14;


int son = 10;


cin >> son;

cout << son << " * 2 = "     << son *2 <<"\n";
cout << son << " * 3 = "     << son *3 <<"\n";
cout << son << " * 4 = "     << son *4 <<"\n";
cout << son << " * 5 = "     << son *5 <<"\n";
cout << son << " * 6 = "     << son *6 <<"\n";
cout << son << " * 7 = "     << son *7 <<"\n";
cout << son << " * 8 = "     << son *8 <<"\n";
cout << son << " * 9 = "     << son *9 <<"\n";
cout << son << " 5* 10 = "     << son *10 <<"\n";


int yosh;


cin >> yosh;

cout << 2022 -yosh << "\n" ;

*/




/*
int a = 23;
int b = 56;
int c = 12;
cout << a << " + 56 = " << a +b << "\n";
cout << b << " + 12 = " << b +c << "\n";
cout << c << " + 23 = " << c +a << "\n";
*/
/*
float x = 2.56;
float y = 6.87;
float z = 43.67;
cout << x <<  " * 6.87 = " << x *y << "\n";
cout << y <<  " * 43.67 = " << y *z << "\n";
cout << z <<  " * 2.56 = " << z *x << "\n";

/*
bool bir = true;
bool ikki = false;
cout << bir << "\n";
cout << ikki << "\n";
*/
/*
string FirstName = "Odiljon";
string LastName = "Toirjonov";
cout << LastName << "\n";
cout << FirstName << "\n";
*/
/*
char gg = 'A';
char vp = 'E';
cout << gg << "\n";
cout << vp << "\n";
*/
/*
int son;
float kasir;
cin >> son;
cin >> kasir;
cout << son << "\n";
cout << kasir << "\n";
*/
/*
int a;
cin >> a;
cout << a -122 << "\n";
*/

/*
int a, b, S;


cout << "a tomon" ;
cin >> a;
cout << "b tomon" ;
cin >> b;

S = a * b;

cout << " bu togri tortborchkni qiymati: "  << S << "ga teng";
*/
/*
int r;
double pi = 3.14;
double L;

cout << "aylanani uzunligi";
cin >> r;

L = 2 * pi * r;

cout << "bu aylanani uzunligi"   << L <<   "ga teng" ;
*/

/*
 float L, S, R;
 float const pi=3.14;
 cout << "R=" ;
 cin >> R;
 L = 2 * pi * R;
 S = pi * (R * R);
 cout << "L=" << L;
 cout << "S=" << S;

*/
/*
int a, b;

cout << "a ga sin kirit : ";
cin >> a;
cout << "b ga sin kirit : ";
cin >> b;


cout << "javop " << a+b << " ga teng " << endl;
cout << "javop " << a/b << " ga teng"<< endl;
*/
/*
float a, b, c, d;
cout << "sm kirit : ";
cin >> a;

b = a / 100;
c = a / 100000;

cout  << b <<  " metrga teng " << endl;
cout  << c <<  " kilometrga teng " << endl;
*/
/*
int a, b;
cout << " son kirit: " ;
cin >> a;
cout << "daraja kirit";
cin >> b;

cout << " sonini darajasi " << pow(a, 2) << " boladi tekshirvol ";
*/

//cout << "Hello World";
/*
cout << "                                            " << endl;
        cout << "     C  C                                   " << endl;
        cout << "  C        C        +             +         " << endl;
        cout << "  C                 +             +         " << endl;
        cout << "  C             + + + + +     + + + + +     " << endl;
        cout << "  C                 +             +         " << endl;
        cout << "  C       C         +             +         " << endl;
        cout << "    C  C                                    " << endl;
        cout << "                                            " << endl;
*/
/*
float x,y,z,d;
x=1;
y=2;
z=3;

d=x*y*z;

cout << " Yig'indisi : "  << d << " ga teng "<< endl;

       return 0;

*/
/*
bool bir = true;
bool ikki = false;
cout << bir << " True " << "\n";
cout << ikki << " False "<<  "\n";
*/
/*
int a;
float b, d;
cout <<"hohlagan soningizni kiriting : ";
cin >> a;
cout << "hohlagan soningizni kiriting  : ";
cin >> b;
d = a + b;
cout << "siz kiritgan sonlarni yigindisi " << d << "ga teng";
*/
/*

int a,b,c,d;
a=6;
b=12;
c=34;

d = a + b + c ;

cout << " Yig'indisi : 6 + 12 + 34 = "  << d << " ga teng "<< endl;
*/
/*
double a;
cout << " santimetr kiriting uni metr va kilonetrlarga ogirib beraman : ";
cin >> a;
cout << " siz kiritgan santimetrni metiri : " << a / 100 << "\n";
cout << " siz kiritgan santimetrni kilometiri :0 " << a / 1000000 << "\n";
*/
/*
int a = 4567;

cout << "sonni kirit : " ;

cin >> a;
int minglar = a % 1000;
a = a % 1000;
int yuzlar = a / 100;
a = a % 100;
int onlar = a / 10;
a = a % 10;
int birlar = a / 10;

cout << "raqamlar yigindisi:" << yuzlar + minglar;
*/
/*
int a = 7368;

cout << "sonni kirit : " ;

cin >> a;
cout << "minglar" << a << "\n";
int minglar = a % 1000;
a = a % 1000;
cout << "yuzlar" << a <<"\n";

int yuzlar = a / 100;
a = a % 100;

cout << "onlar" <<  a << "\n";
int onlar = a / 10;
a = a % 10;

cout << "birlar" << a <<  "\n";
int birlar = a / 1;

cout << "raqamlar yigindisi:" << yuzlar + minglar;
*/
/*
int a = 3;

a++;
///4
--a;
///3
a++;
///4
a = --a + ++a;
cout << a++;
*/
/*
int z = 10;

z += 5;
z -= 10;
z *= 20;
z -= 5;
cout << z;
*/
/*
string name = "nomli";
name += 20;
cout << name;
*/

/// && = va   (and)
/// || = yoki (or)
///  ! = inlor (not)
/*
/// Birinchi bosqich
int a, b;
cout << "sonni kirit : " ;
/// o'rta bosqich
cin >> a;
int z = a / 10;
a = a % 10;
b = a + z;
/// yakuniy bosqich
cout << "raqamlar yigindisi:"<<  b << endl;
*/
/*
/// Birinchi bosqich
int a,b,c,d;
cout<<"Ikki xonali son kiriting->";
/// o'rta bosqich
cin>>a;
b=a/10;
c=a-b*10;
d=10*c+b;
/// yakuniy bosqich

cout<<"Uning raqamlarini almashtirishdan hosil bo'lgan son->"<<d;
*/



/*
/// Birinchi bosqich
int a,b,c,d,e,f;
cout<<"uch xonali sonni kiriting->";
cin>>a;

/// o'rta bosqich
b=a/100;
c=a-b*100;
d=c/10; e=c-d*10;
f=b+10*d+100*e;

/// yakuniy bosqich
cout<<"uning raqamlarining o'rnini almashtirishdan hosil bo'lgan son->"<<f;
*/

/*
/// Birinchi bosqich
int a,b,c,d,e,f;
cout<<"uch xonali sonni kiriting->";
cin>>a;

/// o'rta bosqich
b=a/100;
c=a-b*100;
d=c/10;
e=c-d*10;
f=b+100*d+10*e;

/// yakuniy bosqich
cout<<"Uning chapdan birinchi raqamini o'chirib o'ng tarafiga yozishdan hosil bo'lgan son->"<<f;
*/

/*
int a,b,c,d,e;
cout<<"Kun boshidan boshlab o'tgan sekund->";cin>>a;
b=a/3600;
c=a-b*3600;
d=c/60;
e=c-d*60;
cout<<"Kun boshidan boshlab o'tgan to'la soat->"<< b << endl;
cout<<" minut->"<< d << endl ;
cout<<" sekund->"<< e << endl;
*/

/*
int a, b, c;
cout << "butun son kiriting :" ;
cin >> a;
b = a % 10;

cout << "kiritgan soningizni ohirigi raqani = "  << b ;
*/

/*

int symbol;
cout << "enter number: "; cin >> symbol;
cout << "ASCII counterpart:
*/
/*
int a = 4;
int b = 6;
int c;
c = a;
a = b;
b = c;

cout << a << endl;
cout << b << endl;
*/
/*
int a = 6;
int b = 4;

a = a + b;
b = a - b;
a = a - b;
cout << a << endl;
cout << b << endl;
*/
/*
string a = "Hi";
int b = 98;
char c = '!';
bool d = true;
double e =  23.89;
float f = 3.5;

cout << a << " Bu string qiymati" << endl;
cout << b << " Bu int qiymati" << endl;
cout << c << " Bu char qiymati" << endl;
cout << d << " Bu bool qiymati" << endl;
cout << e << " Bu double qiymati" << endl;
cout << f << " Bu float qiymati" << endl;
*/
/*
const double PI = 3.14;
int r;

cout << " radiusni kirit ";
cin >> r;

///4/3 * PI * R^3

cout << " bu sharni hajmi "  << 4 * PI * r * r * r / 3;
*/
/*
int a, b, c;
cout << "4 honali son kiriting";
cin >> a;
*/
/*
int a;
/// ///////////////////////////////////freggv4g4rgrt4gv
cout << "sonni kirit : " ;

cin >> a;
int minglar = a / 1000;
a = a % 1000;
int yuzlar = a / 100;
a = a % 100;
int onlar = a / 10;
a = a % 10;
int birlar = a;

cout << "raqamlar yigindisi:" << (birlar + onlar + yuzlar + minglar)  / 4.0;
*/

/*
int a,b,c,d,e;
cout<<"Kun boshidan boshlab o'tgan sekund->";cin>>a;
b=a/3600;
c=a-b*3600;
d=c/60;
e=c-d*60;
cout<<"Kun boshidan boshlab o'tgan to'la soat->"<< b << endl;
cout<<" minut->"<< d << endl ;
cout<<" sekund->"<< e << endl;
*/

/*
double a;
double b;
bool c;
bool z;
cout << "hohlagan son kiriting: ";
cin >> a;
cout << "hohlagan son kiriting: ";
cin >> b;

c = a > 0;
z = b > 0;



cout << "siz manfiy son kirittingiz " << c || z;
//cout << "siz manfiy son kirittingiz " << b << endl;
*/

/*
double a;
double b;

cout << "hohlagan son kiriting: ";
cin >> a;
cout << "hohlagan son kiriting: ";
cin >> b;

bool chek1 = a < 0 && b > 0;
bool chek2 = a > 0 && b < 0;


cout << "siz manfiy son kirittingiz " << (chek1 || chek2) ;
*/


/*
int a, b;
cout << "birinchi sonni kirit :";
cin >> a;
cout << "ikkinchi sonni kirit :";
cin >> b;
if(a > b){
    cout << a;
}
else{
    cout << b;

}
*/

/*
int a, b;
cout << "son kiriting :";
cin >> a;
cin >> b;
if (a > b){
     cout << a ;
}


else if(b > a){
     cout << b;
}
else if (a == b){
     cout << a + b;

}


else{
    cout << "False ";

}
*/

/*
char a;
cout << "son kiriting : ";

if (a==97=a){
    cout << a;
}
else{
    cout << a;
}
*/

/*
int a, b;
cout << "2 ta hohlagan son kiriting va dastur ularni taqqoslaydi " << endl;
cin >> a ;
cin >> b ;

if (a > b){
    cout << a << endl;
}
else {
    cout << b << endl;
}
*/


/*
int a = 6;
int b = 4;

a = a + b;
b = a - b;
a = a - b;
cout << a << endl;
cout << b << endl;
*/
/*
int a, b;
cout << " son kiriting : " ;
cin >> a;
cout << "daraja kiriting : ";
cin >> b;

cout << " sonini darajasi " << pow(a, 6) << " boladi ";

*/
/*
int a;
cout << "son kiriting :";
cin >> a;
int minglar = a / 100;
a = a / 100;
a = a * 100;
int yuzlar = a / 100;
a = a / 100;
a = a * 100;

cout << "minglar honasi " << minglar << endl;
cout << "yuzlar honasi " << yuzlar << endl;
*/
/*
int a,b,c,d,e,f;
cout<<"to'rt xonali sonni kiriting->"
;cin>>a;
b=a/1000;
c=a-b*1000;
d=c/100;
e=c-d*100;
cout<<"berilgan sonning yuzliklar xonasidagi son->"<<d;
*/

/*
int a,b;


cout << "son kiriting :"<<endl;
cin>>a;

if (a<97){
    cout<<"Xato son kiritdingiz";
}

else if (a>122){
    cout<<"Xato son kiritdingiz";
}


else if (97 < a ) {
    cout << "Togri son kirittingiz" << endl;

}

else if (122 > a ) {
    cout << "Togri son kirittingiz" << endl;

}
*/
/*
int a;
cout << "son kiriting :";
cin >> a;
a = 234;

cout << ((a / 100 > 0 && a / 100 < 10 ) && (a % 2 == 0));
*/

/*
int n1, n2, f;
const double m1 = 3.1, m2 = 2.1;
cout << "birinchi fan: ";
cin >> n1;
cout << "ikkinchi fan: ";
cin >>  n2;
cout << "imtiyozingiz: ";
cin >> f;

cout << "Sizni toplagan balingiz"<< (n1 * m1 * n2 * m2)*(100+f)/100;

*/
/*
int a, b;
cout << " son kiriting : " ;
cin >> a;

if (a > 0)
    cout << "sonni kvadrati "<< a * a<< endl;
*/
/*
int a, b, c;
cout << "2 ta son kiriting: ";
cin >> a;
cin >> b;
cin >> c;
if (a > b){
    cout << a;
}
else if (a < b){
    cout << b;
}
*/
/*
int a;
cout << " son kirit : "<<endl;
cin >> a;

if(a % 3 == 0 && a % 5 == 0) {
cout << " FizzBuzz " << endl;
}
else if(a % 3 == 0) {
cout << " Buzz " << endl;
}
else if(a % 5 == 0) {
cout << " Fizz " << endl;
}
else {
cout << " son " <<a << endl;
}
*/
/*
char a;
cout << "hohlagan narsa kiriting: ";
cin >> a;
if((a >= 'a' && a <= 'z') || (a >= 'A' && a <= 'Z')){
cout << " siz harif kiritingiz" ;
}
else if (a >= 48 && a <= 57){
cout<< " siz son kiritingiz";
}
cout << endl;
*/
/*
int a, b, c;
cin >> a;
cin >> b;
cin >> c;

if (a > b){
        if (a > c)
            cout << a;
        else
            cout << c;

}
else if (b > c)
    cout << b;
else
    cout << c;
*/
/*
bool a, b;
int x, y, z;
cout << " 3 ta hohlagan son kiriting" "\n";
cin >> x;
cin >> y;
cin >> z;
a = true;
b = false;
if (x < y < z){
        cout << a;
*/
/*
int a,b,c;

cout<<"3 ta son kiriting"<< "\n";
cin>>a>>b>>c;
if(a<b&&a<c)
{
if(b<c)
{
cout<<a<<b<<c;
}
else if(c<b)
{
cout<<a<<c<<b;
}
}
else if(b<a&&b<c)
{
if(a<c)
{
cout<<b<<a<<c;
}
else if(c<a)
{
cout<<b<<c<<a;
}
}
else if(c<a&&c<b)
{
if(a<b)
{
cout<<c<<a<<b;
}
else if(b<a)
{
cout<<c<<b<<a;
}
}
else
cout<<"Mumkin emas";

*/
/*
int number;
int number2;

cout << "sonni kirit: " << endl;
cin >> number;
cin >> number2;

int birinchi = number % 100;

int ikkinchi = number / 100;

int birinchi2 = number2 % 100;

int ikkinchi2 = number2 / 100;


cout << "raqamlar yig'indisi:" << birinchi + ikkinchi  + birinchi2 + ikkinchi2;
*/

/*
int a, b, c;
cout << "3 ta son kiriting";
cin >> a;
cin >> b;
cin >> c;

a < b;
c > a;
cout  << c ;

*/
/*
int a, b, c;
cout << "3 ta butun son kiriting :";
cin >> a;
cin >> b;
cin >> c;

cout << a << b << c;

*/
/*
int a, b, c;
cout << "3 ta son kiriting";
cin >> a;
cin >> b;
cin >> c;

a < b;
c > a;
cout  << c ;
*/
/// /////////////////////////////////////UYGA VAZIFALAR 8 - 9 DARS
/*
char a, b;
cout << "2ta son kiriting va dasstur kattasini topadi" << "\n";
cin >> a;
cin >> b;
if (a > b){
    cout <<  (a);
}

else {
    cout << (b);
}
*/
/*
int a,b,c;
cout<<"3 ta son kiriting"<< "\n";
cin>>a>>b>>c;
if(a<b&&a<c)
{
if(b<c)
{
cout<<a<<b<<c;
}
else if(c<b)
{
cout<<a<<c<<b;
}
}
else if(b<a&&b<c)
{
if(a<c)
{
cout<<b<<a<<c;
}
else if(c<a)
{
cout<<b<<c<<a;
}
}
else if(c<a&&c<b)
{
if(a<b)
{
cout<<c<<a<<b;
}
else if(b<a)
{
cout<<c<<b<<a;
}
}
else
cout<<"Mumkin emas";
*/
/*
int a;
cout << "Necha Ball olganizni kiriting:";
cin >> a;
if (a >= 00 && a <=55){
cout << "Qonigarsiz!" ;
}
else if (a >= 56 && a <= 70){
cout << "Qonigarli";
}
else if (a >= 71 && a <= 85) {
cout <<"Yaxshi";
}
else if (a >= 86 && a <= 100) {
cout <<"A'lo";
}
*/
/*
int a, b, c;
cout << "son kiriting: ";
cin >> a;
cout << "son kiriting:";
cin >> b;
cout << "son kiriting:";
cin >> c;
if (a>b) {
cout << a;
}
else if (a>c) {
cout << a;
}
else {
cout << b;
}
*/

///                                           platforma
/*
int a, b, c;
bool s = true;
cout << "3 ta butun son kiriting :";
cin >> a;
cin >> b;
cin >> c;

cout << s;
*/

/*
int number;
int number2;

cout << "sonni kirit: " << endl;
cin >> number;
cin >> number2;

int birinchi = number % 100;

int ikkinchi = number / 100;

int birinchi2 = number2 % 100;

int ikkinchi2 = number2 / 100;


cout << "raqamlar yig'indisi:" << birinchi + ikkinchi  + birinchi2 + ikkinchi2;

*/
/*
int a;
cout << "son kiriting :";
cin >> a;
if (a > 0){
    cout << "musbat son kiritingiz";
}
else if (a < 0){
    cout << "manfiy son kiritingiz";

}
else
    cout << "0 kiritingiz";

*/
/*
int a;
cout << "1 gan 7 gacha son kiriting :";
cin >> a;
if (a == 1){
    cout << " Dushanba ";
}
else if (a == 2){
    cout << " seshanba ";
}
else if (a == 3){
    cout << " chorshanba ";
}
else if (a == 4){
    cout << " payshanba ";
}
else if (a == 5){
    cout << " juma ";
}
else if (a == 6){
    cout << " shanba ";
}
else if (a == 7){
    cout << " yakshanba ";
}
else  {
    cout << " unday hafta kuni yoq";
}
*/
/*
int a;
cout << "a=";
cin >> a;

cout << ((a % 2 ==  0) ? "juft " : "toq");
*/
/*
int a;
cout << "oylarni kiriting";
cin >> a;

cout << ((a == 1) ? "31 kun" : "");
cout << ((a == 2) ? "28 kun" : "");
cout << ((a == 3) ? "31 kun" : "");
cout << ((a == 4) ? "30 kun" : "");
cout << ((a == 5) ? "31 kun" : "");
cout << ((a == 6) ? "30 kun" : "");
cout << ((a == 7) ? "31 kun" : "");
cout << ((a == 8) ? "31 kun" : "");
cout << ((a == 9) ? "30 kun" : "");
cout << ((a == 10) ? "31 kun" : "");
cout << ((a == 11) ? "30 kun" : "");
cout << ((a == 12) ? "31 kun" : "");
*/
/*
int a, b, c;
cout << "uchbirchakni yigindisini kiriting";
cin >> a;
cin >> b;
cin >> c;

cout << ((a+b+c == 180) ? "togri" : "notogri");
*/
/*
int a, b, c;
cout << "uchburchakni burchakini kiriting :";
cin >> a;
cin >> b;
cin >> c;

if (a == b && b == c){
    cout << "teng tomoli";
}
else if (a != b && b != c){
    cout << j"turli tomonli";
}
else if (a != b && b == c){
    cout << " teng yonli";
}
else {
    cout << "notogri";
}
*/
/*
int x, y, z;
cin >> x;
cin >> y;
cin >> z;

cout << ((x > y && y <= z ) ? "1" : "0");
*/
/*
int a, b;
cout << "son kiriting :";
cin >> a;
cin >> b;
cout << ((a == b) ? "1" : "0")<< "\n";
cout << ((a != b) ? "1" : "0")<< "\n";
*/
/*
int a;
cout << "-999 dan 999 gacha son kiriting :";
cin >> a;

if (a > 0 && a <= 9)
    cout << "1 honali musbat son";
else if (a <= -1 && a >= -9)
    cout << "1 honali manfiy son";
else if (a >= 10 && a <= 99)
    cout << "ikki honali musbat son";
else if (a <= -10 && a <= -99)
    cout << "ikki honali musbat son";
else if (a >= 100 && a <= 999)
    cout << "ikki honali musbat son";
else if (a >= -100 && a <= -990)
    cout << "ikki honali musbat son";
else
    cout << "notogri son";
*/
/*
int yil;
cout<<("Yilni kiriting : ");
cin>>yil;

if(((yil % 4 == 0) && (yil % 100 !=0)) || (yil % 400==0))
{021
cout<<("Kabisa yili");
}202
else
{
cout<<("Kabisa yili emas");
}
*/
/*
double a,b = 270000, tax;
cout << "oylik kiriting";
cin >> a;

if (a <= 5*b)
    tax = a * 0.09;
else if (a > 5*b && a <= 10 * b )
    tax = a * 0.16;

else tax = a * 0.23;

cout << "sizning daromat soligingiz" << tax << "som ";
*/
/*
char a;
cin >> a;

switch(a){
    case '+': {
        cout << "qoshish amalini kiritingiz";
        break;
    }
    case '-' : {
        cout << "ayirish amali";
        break;
    }

    case '*' : {
        cout << "kopaytirish amali";
        break;
    }

    case '/' :{
        cout << "bolish amali";
        break;

    }
    default:
        cout << "siz amal kiritmadingiz";




}
*/
/*
int a;

cin >> a;

switch(a){
    case 1 :{
        cout << "bu ish kuni";
        break;
    }
    case 2:{
        cout << "bu ish kuni";
        break;
    }
    case 3:{
        cout << "bu ish kuni";
        break;
    }
    case 4:{
        cout << "bu ish kuni";
        break;
    }
    case 5:{
        cout << "bu ish kuni";
        break;
    }
     case 6:{
        cout << "bu ish kuni";
        break;
    }
     case 7:{
        cout << "bu dam olish kuni";
        break;

    }
     default:
        cout << "siz notogri malumot kiritingiz";
}
*/
/*
int a;

cin >> a;

switch(a){
    case 1 :{
        cout << "Yanvar";
        break;
    }
    case 2:{
        cout << "Fevral";
        break;
    }
    case 3:{
        cout << "Mart";
        break;
    }
    case 4:{
        cout << "Aprel";
        break;
    }
    case 5:{
        cout << "May";
        break;
    }
     case 6:{
        cout << "Iyun";
        break;
    }
     case 7:{
        cout << "Iyul";
        break;

    }
     case 8:{
        cout << "Avgust";
        break;

    }
     case 9:{
        cout << "sentyabr";
        break;

    }
     case 10:{
        cout << "oktyabr";
        break;

    }
     case 11:{
        cout << "noyabr";
        break;

    }
     case 12:{
        cout << "dekabr";
        break;



     default:
        cout << "siz notogri malumot kiritingiz";
}
*/
/*
int a;

cin >> a;

switch(a){
    case 1:{
    case 2:
    case 12:
        cout << "Qish";
        break;
    }

    case 3:{
    case 4:
    case 5:
        cout << "Bahor";
        break;
    }
     case 6:{
     case 7:
     case 8:
        cout << "Yoz";
        break;
    }
     case 9:{
     case 10:
     case 11:
        cout << "Kuz";
        break;

    }



     default:{
        cout << "siz notogri malumot kiritingiz";
}
}
*/

/*
cout << ((a == 1) ? "31 kun" : "");
cout << ((a == 2) ? "28 kun" : "");
cout << ((a == 3) ? "31 kun" : "");
cout << ((a == 4) ? "30 kun" : "");
cout << ((a == 5) ? "31 kun" : "");
cout << ((a == 6) ? "30 kun" : "");
cout << ((a == 7) ? "31 kun" : "");
cout << ((a == 8) ? "31 kun" : "");
cout << ((a == 9) ? "30 kun" : "");
cout << ((a == 10) ? "31 kun" : "");
cout << ((a == 11) ? "30 kun" : "");
cout << ((a == 12) ? "31 kun" : "");
*/
/*
int a;

cin >> a;

switch(a){
    case 1:{
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
        cout << "31";
        break;
    {



    case 4:{
    case 6:
    case 9:
    case 11:
        cout << "30";
        break;
    }

    case 2:{
        cout << "28";
        break;
    }

     default:
        cout << "siz notogri malumot kiritingiz";
}
*/
/*
int a, b;
cin >> a;
cin >> b;

switch (a < b){
    case 0: {
        cout << "katta son " << a ;
        break;
    }
    case 1: {
        cout << "katta son " << b;
        break;

    }
*/
/*
int a, b;
cout << "son kiriting :";
cin >> a;
cin >> b;
cout << ((a == b) ? "1" : "0")<< "\n";
cout << ((a != b) ? "1" : "0")<< "\n";
*/

/*
int a = 0;
int b = 0;
char z;
cout << "1 son kiriting : ";
cin >> a;
cout << "2 son kiriting : ";
cin >> b;
cout << "amal kiriting : ";
cin >> z;

switch (z){
      case '-':
        cout << "a - b = " << a - b << endl;
          break;
      case '+':
        cout << "a + b = " << a + b << endl;
          break;
      case '*':
        cout << "a * b = " << a * b << endl;
          break;
      case '/':
        cout << "a / b = " << a / b << endl;
    case '%':
        cout << "a % b = " << a % b << endl;
          break;
      default:
        cout << "notogri malumot";
}
*/
/*
int a;
string read = "";
cout << "1 dan 999 gacha son kiriting :";
cin >> a;

int birlar = a % 10;
a /= 10;
int onlar = a % 10;
int yuzlar = a / 10;

switch(yuzlar){
    case 1:
        read += "bir yuz";
        break;
    case 2:
        read += "ikki yuz";
        break;
    case 3:
        read += "uch yuz";
        break;
    case 4:
        read += "tort yuz";
        break;
    case 5:
        read += "besh yuz";
        break;
    case 6:
        read += "olti yuz";
        break;
    case 7:
        read += "yetti yuz";
        break;
    case 8:
        read += "sakkis yuz";
        break;
    case 9:
        read += "toqqiz yuz";
        break;

}

switch(onlar){
     case 1:
        read += "on";
        break;
    case 2:
        read += "yigirma";
        break;
    case 3:
        read += "ottiz";
        break;
    case 4:
        read += "qirq";
        break;
    case 5:
        read += "ellik";
        break;
    case 6:
        read += "otmush";
        break;
    case 7:
        read += "yetmush";
        break;
    case 8:
        read += "sakson";
        break;
    case 9:
        read += "toqson";
        break;
}
switch(birlar){
    case 1:
        read += "bir";
        break;
    case 2:
        read += "ikki";
        break;
    case 3:
        read += "uch";
        break;
    case 4:
        read += "tort";
        break;
    case 5:
        read += "besh";
        break;
    case 6:
        read += "olti";
        break;
    case 7:
        read += "yetti";
        break;
    case 8:
        read += "sakkis";
        break;
    case 9:
        read += "toqiz";
        break;

}
*/

/*
  int til, realPin = 2515, checkPin, action;
    double balance = 1000000;

    cout << "ATM ga xush kelibsiz!\nWelcome\n\n";

    cout << "Tilning tanlang\tChoose language\n";
    cout << "1. O'zbek tili\t2. English\n >> ";
    cin >> til;

    switch(til){
        case 1:{
            cout << "Pin kodni kiriting: ";
            cin >> checkPin;

            if(realPin == checkPin){
                cout << "Xizmatlar\n";
                cout << "1. Pul yechish\t2. Hisobni to'ldirish\t3. Balans\t0. Chiqish\n";
                cin >> action;

                switch(action){
                    case 1:{
                        double money;
                        cout << "Qancha pul yechmoqchisiz: ";
                        cin >> money;

                        if (balance < money){
                            cout << "hisobingizda mablag' yetarli emas";
                            break;
                        }

                        balance -= money;
                        cout << "sizda " << balance << " so'm qoldi";
                        break;
                    }
                    case 2: {
                        double money;
                        cout << "qancha pul tashlamoqchisiz: ";
                        cin >> money;

                        balance += money;
                        cout << "sizda " << balance << " so'm bor";
                        break;
                    }
                    case 3: {
                        cout << "sizda " << balance << " so'm bor";
                        break;
                    }
                    case 0: {
                        cout << "Xizmatlarimizdan foydalanganingiz uchun rahmat";
                        break;
                    }
                    default:
                        cout << "Noto'g'ri qiymat || Wrong input";
                }
            }else{
                cout << "Noto'g'ri pin kod kiritdingiz";
            }

        }
            break;
        }
        switch(til){
        case 2:{
            cout << "enter the pin code: ";
            cin >> checkPin;

            if(realPin == checkPin){
                cout << "Services\n";
                cout << "1 Withdrawal \ t2. Top up account \ t3. Balance \ t0.Exit";
                cin >> action;

                switch(action){
                    case 1:{
                        double money;
                        cout << "how much money do you want to withdraw : ";
                        cin >> money;

                        if (balance < money){
                            cout << "not enough money";
                            break;
                        }

                        balance -= money;
                        cout << "in you" << balance << "soums left";
                        break;
                    }
                    case 2: {
                        double money;
                        cout << "how much money do you want to throw away: ";
                        cin >> money;

                        balance += money;
                        cout << "in you " << balance << " soums left";
                        break;
                    }
                    case 3: {
                        cout << "in you " << balance << "soums left";
                        break;
                    }
                    case 0: {
                        cout << "Bye";
                        break;
                    }
                    default:
                        cout << "Noto'g'ri qiymat || Wrong input";
                }
            }else{
                cout << "You entered the wrong pin code";
            }


            break;
        }



        default:
            cout << "Noto'g'ri qiymat || Wrong input";
    }
*/

///           8-dars prezentatsiyaning oxiridagi barcha masalalar
/// 2 ta sonni katasini topuvchi dastur
/*
int a, b;
cout << "2 ta son kiriting va dastur ularni kattasini topadi :";
cin >> a,
cin >> b;
if (a > b){
    cout << a;

}
else {
    cout << b;
}
*/
/// 3 ta sonni katasini topuvchi dastur
/*
int a, b, c;
cout << "3 ta son kiriting va dastur ularni kattasini topadi";
cin >> a;
cin >> b;
cin >> c;

if (a > b){
    cout << a;
}
else if (a > c){
    cout << a;
}
else{
    cout << b;
}
*/
/// Berilgan 3 ta sonni o’sish tartibida chiqaring
/*
int a, b, c;
cin >> a;
cin >> b;
cin >> c;
int maxNUM = max(c, max(a, b));
int minNUM = min(c, min(a, b));
int middle = a + b + c - minNUM - maxNUM;
cout << "\n\n" << minNUM << "\n" << middle << "\n" << maxNUM;
*/

/// Qiymati [-999; 999] oraliqda yotuvchi butun son berilgan.
/*
int a;
cout << "-999 dan 999 gacha son kiriting";
cin >> a;
if (a >= 1 && a <= 9)
    cout << "bir honali musbat son";
else if (a <= -1 && a >= -9)
    cout << "bir honali manfiy";
else if (a >= 10 && a >= 99)
    cout << "ikki honali musbat";
else if (a >= -10 && a >= -99)
    cout << "ikki honali manfiy";
else if (a >= 100 && a >= 999)
    cout << "uch honali musbat";
else if (a >= -100 && a >= -999)
    cout << "uch honali manfiy";
else
    cout << "hato";
*/
///  Qiymati [1; 9999] bo‘lgan x butun soni berilgan.
/*
int a;
cout << "1 dan 9999 gacha bolgan son kiriting";
cin >> a;
if (a >= 1 && a <= 9)
    cout << "bir honali toq";
else if (a >= 10 && a >= 99)
    cout << "ikki honali toq";
else if (a >= 100 && a >= 999)
    cout << "uch honali toq";
else if (a >= 1000 && a >= 9999)
    cout << "tort honali toq";
else
    cout << "hato";
*/
///Foydalanuvchi tomonidan kiritilgan yilning kabisa yili yoki kabisa yili emasligini aniqlang.
/*
int yil;
cout << "yilni kirit";
cin >> yil;
if ((yil % 4 == 0 && yil % 100 != 0) || (yil % 400 == 0))
    cout << "kabisa yili";
else
    cout << "Kabisa emas";
*/
/// Semestr davomida talaba to’plagan reyting ballga mos ravishda uning o’zlashtirishi haqida xabar chiqaring:
/*
int n1, n2, f;
const double m1 = 3.1, m2 = 2.1;
cout << "birinchi fan: ";
cin >> n1;
cout << "ikkinchi fan: ";
cin >>  n2;
cout << "imtiyozingiz: ";
cin >> f;

cout << "Sizni toplagan balingiz"<< (n1 * m1 * n2 * m2)*(100+f)/100;
/*
int a, b;
double money;
cout << "Valyuta kirit";
cout << "1 UZS \t 2 USD \t 3 EUR \t 4 RUB\n" << endl ;
cin >> a;

cout << "qancha otkazasan";
cin >> money;

cout << " otkazmoqchi valyutani kirit" << endl;
cout << "1 UZS \t 2 USD \t 3 EURl\t 4 RUB\n"<<endl ;
cin >> b;

switch(a){
    case 1:{
        switch(b){
        case 1:{
             cout << money << "so'm =" << money << "so'm";
             break;
        }
        case 2:{
            cout << money << "so'm = " << money / 10830 << " $ ";
            break;

        }



        }






    }




}
*/


/*
int a, b;
double money;
cout << "Valyuta kirit";
cout << "1 UZS \t 2 USD \t 3 EUR \t 4 RUB\n" << endl ;
cin >> a;

cout << "qancha otkazasan";
cin >> money;

cout << " otkazmoqchi valyutani kirit" << endl;
cout << "1 UZS \t 2 USD \t 3 EURl\t 4 RUB\n"<<endl ;
cin >> b;

switch(a){
    case 1:{
        switch(b){
        case 1:{
             cout << money << "so'm =" << money << "so'm";
             break;
        }
        case 2:{
            cout << money << "so'm = " << money / 10830 << " $ ";
            break;
        }
        }
    }

}
*/

/*
int a,b;
cout<<"Oylik maoshoingizni kiriting : ";
cin>>a;
cout<<"Eng kam oylik ish haqqi miqdorini kiriting : ";
cin>>b;


if (a<=5*b){
    cout<<"Daromad solig'ingiz 9 foiz";
}
else if (a > 5*b && a < 10*b){
    cout<<"Sizning daromad solig'izgiz 16 foiz ";
}
else if (a > 10*b){
    cout<<"Daromad solig'ingiz 23 foiz ";
}
*/
/// HOMEWORK
/*
bool a = true, b = false, c = false, d = true;

///  7) int c = ++a - b++ * 2 - a++ + ++b;
///  8) int c = a-- + 2 * ++a - a--;
///  9) int c = ++a * --a + ++b - b++;
/// 10) int c = a-- + --b - ++a * --b - b++; == -11
/// 11) cout << a && b || (c && d) || !(d && c); == true
/// 12) cout << (c || d && (a && d)) || !(d && c); == true
cout << (a || !b) && c || (d && a);
*/

/*
int a, b;
string read = "";
cout << "oy va kun kiriting";
cin >> a;
cin >> b;


switch(b){
    case 1:
        read += "2";
        break;
    case 2:
        cout << "3";
        break;
    case 3:
        cout << "4";
        break;
    case 4:
        cout << "5";
        break;
    case 5:
        cout << "6";
        break;
    case 6:
        cout << "7";
        break;
    case 7:
        cout << "8";
        break;
    case 8:
        cout << "9";
        break;
    case 10:
        cout << "11";
        break;
    case 11:
        cout << "12";
        break;
    case 12:
        cout << "13";
        break;
    case 13:
        cout << "14";
        break;
    case 14:
        cout << "15";
        break;
    case 15:
        cout << "16";
        break;
    case 16:
        cout << "17";
        break;
    case 17:
        cout << "18";
        break;
    case 18:
        cout << "19";
        break;
    case 19:
        cout << "20";
        break;
    case 20:
        cout << "21";
        break;
    case 21:
        cout << "22";
        break;
    case 22:
        cout << "23";
        break;
    case 23:
        cout << "24";
        break;
     case 24:
        cout << "25";
        break;
     case 25:
        cout << "26";
        break;
     case 26:
        cout << "27";
        break;
     case 27:
        cout << "28";
        break;
     case 28:
        cout << "29";
        break;
     case 29:
        cout << "30";
        break;
     case 30:
        cout << "31";
        break;
     case 31:
        cout << "1";
        break;


}
switch(a){
    case 1:
        cout << "yanvar";
        break;
    case 2:
        cout << "fevral";
        break;
    case 3:
        cout << "mart";
        break;
    case 4:
        cout << "aprel";
        break;
    case 5:
        cout << "may";
        break;
    case 6:
        cout << "iyun";
        break;
    case 7:
        cout << "iyul";
        break;
    case 8:
        cout << "avgust";
        break;
    case 9:
        cout << "sentyabr";
        break;
    case 10:
        cout << "oktyabr";
        break;
    case 11:
        cout << "noyabr";
        break;
    case 12:
        cout << "dekabr";
        break;
}
*/
/*
int a, b, c;
cout << "3 ta son kiritng"<< endl;
cin >> a;
cin >> b;
cin >> c;
if (a > b && b > c){
    cout << a << "n" << b << endl;
}
else if (a < b && b < c){
    cout << b << "\n" << c << endl;
}
else {
    cout << a << "\n" << c << endl;
}
a = a + b + c;
cout << a << endl;
*/

/*
int a;
cin >> a;
cout << ((a == 1) ? "31 kun" : "");
cout << ((a == 2) ? "28 kun" : "");
cout << ((a == 3) ? "31 kun" : "");
cout << ((a == 4) ? "30 kun" : "");
cout << ((a == 5) ? "31 kun" : "");
cout << ((a == 6) ? "30 kun" : "");
cout << ((a == 7) ? "31 kun" : "");
cout << ((a == 8) ? "31 kun" : "");
cout << ((a == 9) ? "30 kun" : "");
cout << ((a == 10) ? "31 kun" : "");
cout << ((a == 11) ? "30 kun" : "");
cout << ((a == 12) ? "31 kun" : "");
*/
/*
int number;
int number2;

cout << "sonni kirit: " << endl;
cin >> number;
cin >> number2;

int birinchi = number % 100;

int ikkinchi = number / 100;

int birinchi2 = number2 % 100;

int ikkinchi2 = number2 / 100;
if (number2 == number){
    cout << true << endl;
}
else {
    cout << false << endl;
}

cout << "raqamlar yig'indisi:" << birinchi + ikkinchi  + birinchi2 + ikkinchi2;
*/
/*
int a = 0;

while(a < 10000){
    cout << a << endl;
    a++;
}
*/
/*
int a, b, i, sum = 0;
cin >> a;
cin >> b;

i = a + 1;
while(i < b){
    sum += i;
    i++;
}

cout << sum;
*/
/*
int a, i = 1, z = 0;
cin >> a;

while(i <= a){
    if(a % i == 0)
    z+=i;
        cout << i << "\t";
    i++;
}
cout << z << "\t";
*/

/*
for (int i = 10000; i >= -9999; i--){
        cout << i << "\t";

}
*/
/*
int a;
cout<<"Son kirit :"<<endl;
cin>>a;


for(int i =0; i<10;i++){
    cout<< i << "x" << a << "=" <<a*i<<endl;
*/
/*
int a = 100;

for (int b = 1; b < 100; b++){
        if (b % 2 != 0){
            cout << b << endl;
        }
}
*/
/*
int a, c = 1;
cin >> a;

for (int b = 1; b <= a; b++ ){
        c *= b;
    cout << a << "! = " << c;

}
*/
/*
int a;
cout << "son kiriting";
cin >> a;

if (a >= 1 && a <= 9){
        cout << "siz 1 honali son kiritingiz";
}
else if (a >= 10 && a <= 99){
        cout << "siz 2 honali son kiritingiz";
}
else if (a >= 100 && a <= 999){
        cout << "siz 3 honali son kiritingiz";
}
else if (a >= 1000 && a <= 9999){
        cout << "siz 4 honali son kiritingiz";
}
else if (a >= 10000 && a <= 99999){
        cout << "siz 5 honali son kiritingiz";
}
else if (a >= 100000 && a <= 999999){
        cout << "siz 6 honali son kiritingiz";
}
else if (a >= 1000000 && a <= 9999999){
        cout << "siz 7 honali son kiritingiz";
}
else if (a >= 10000000 && a <= 99999999){
        cout << "siz 8 honali son kiritingiz";
}
else if (a >= 100000000 && a <= 999999999){
        cout << "siz 9 honali son kiritingiz";
}
else if (a >= 1000000000 && a <= 9999999999){
        cout << "siz 10 honali son kiritingiz";
}

else {
    cout << "juda ko'p son";
}
*/
///1. Foydalanuvchi son kiritadi. Siz shu sonning birinchi va oxirgi raqamlari yig'indisini
///hisoblovchi dastur tuzing. Masalan: 34563459 kiritilsa, birinchi raqam 3, oxirgi raqam 9, ekranga
///3 + 9 = 12 chiqsin.
/*
    int n,a,b,sum;
    cout << "son kiriting :";
    cin >> n;
    a = n;
	b = n % 10;
	for(a = n; a >= 10; a = a/10);
    cout<<"birinchi son" << " == " <<a<<endl;
    cout<<"ohirgi son" <<  " == " <<b<<endl;
	cout<<"yigindisi" << " == " <<a+b<<endl;
*/
/// 2. Foydalanuvchi son kiritadi. Siz sonning barcha raqamlari yig'indisini hisoblovchi dastur tuzing.
/*
int a;
cout << "sonni kirit : " ;

cin >> a;
int yuzming = a / 100000;
a = a % 10000;
int onminglar = a / 10000;
a = a % 1000;
int minglar = a / 1000;
a = a % 1000;
int yuzlar = a / 100;
a = a % 100;
int onlar = a / 10;
a = a % 10;
int birlar = a;

cout << "raqamlar yigindisi:" << (birlar + onlar + yuzlar + minglar + onminglar + yuzming);

*/
/// 3. Foydalanuvchi son kiritadi. Siz uni teskarisini ekranga chiqaruvchi dastur tuzing.
/*
int a;
cout << "son kiritng";
cin >> a;


int w = a / 1000000;
a = a % 1000000;
int x = a / 100000;
a = a % 100000;
int e = a / 10000;
a = a % 10000;
int d = a / 1000;
a = a % 1000;
int c = a / 100;
a = a % 100;
int b = a / 10;
a = a % 10;
cout << a << b << c << d << e << x << w;
*/
/*
int til, realPin = 2515, checkPin, action;
    double balance = 1000000;

    cout << "ATM ga xush kelibsiz!\nWelcome\n\n";

    cout << "Tilning tanlang\tChoose language\n";
    cout << "1. O'zbek tili\t2. English\n >> ";
    cin >> til;

    switch(til){
        case 1:{
            cout << "Pin kodni kiriting: ";
            cin >> checkPin;
            if(realPin == checkPin){
                cout << "Xizmatlar\n";
                cout << "1. Pul yechish\t2. Hisobni to'ldirish\t3. Balans\t0. Chiqish\n";
                cin >> action;


                switch(action){
                    case 1:{
                        double money;
                        cout << "Qancha pul yechmoqchisiz: ";
                        cin >> money;

                        if (balance < money){
                            cout << "hisobingizda mablag' yetarli emas";
                            break;
                        }

                        balance -= money;
                        cout << "sizda " << balance << " so'm qoldi";
                        break;
                    }
                    case 2: {
                        double money;
                        cout << "qancha pul tashlamoqchisiz: ";
                        cin >> money;

                        balance += money;
                        cout << "sizda " << balance << " so'm bor";
                        break;
                    }
                    case 3: {
                        cout << "sizda " << balance << " so'm bor";
                        break;
                    }
                    case 0: {
                        cout << "Xizmatlarimizdan foydalanganingiz uchun rahmat";
                        break;
                    }
                    default:
                        cout << "Noto'g'ri qiymat || Wrong input";
                }
            }else{
                cout << "Noto'g'ri pin kod kiritdingiz";
            }

        }
            break;
        }
        switch(til){
        case 2:{
            cout << "enter the pin code: ";
            cin >> checkPin;

            if(realPin == checkPin){
                cout << "Services\n";
                cout << "1 Withdrawal \ t2. Top up account \ t3. Balance \ t0.Exit";
                cin >> action;

                switch(action){
                    case 1:{
                        double money;
                        cout << "how much money do you want to withdraw : ";
                        cin >> money;

                        if (balance < money){
                            cout << "not enough money";
                            break;
                        }

                        balance -= money;
                        cout << "in you" << balance << "soums left";
                        break;
                    }
                    case 2: {
                        double money;
                        cout << "how much money do you want to throw away: ";
                        cin >> money;

                        balance += money;
                        cout << "in you " << balance << " soums left";
                        break;
                    }
                    case 3: {
                        cout << "in you " << balance << "soums left";
                        break;
                    }
                    case 0: {
                        cout << "Bye";
                        break;
                    }
                    default:
                        cout << "Noto'g'ri qiymat || Wrong input";
                }
            }else{
                cout << "You entered the wrong pin code";
            }


            break;
        }



        default:
            cout << "Noto'g'ri qiymat || Wrong input";
    }
*/

/*
int a;
cout << "son kiritng";
cin >> a;
if (a / 2){
    cout << ++a;
}
else if (a /! 2){
    cout << a++;
}
*/
/*
int a, nbs = 0;
cin >> a;

for(int i = 1; 4 i <= a/2; i++){
    if(a % i == 0)
       nbs += i;
}
if (nbs == a)
    cout << a <<"\n"<< "makammal son";
else
    cout << a <<"\n"<< "mukammal son emas";
*/
/*
int son, maks;

cout << "son kirit";
cin >> son;
if (son == 0)
    cout << "0 kiritng";
else {
    m
}

while(true){
    cout << "son kiriting";
    cin >> son;
    if (son == 0)
        break;
    if(son > maks)
        maks = son;
}
cout << "eng katta son" <<"\n"<< maks;
*/

/*
int a, b, c = 0, sum =0;
  cout << "son kiritng: ";
  cin >> a;
  c = a / 2;
  for(b = 2; b <= c; b++)
  {
      if(a % b == 0)
      {
          cout << "tub son emas" << endl;
          sum = 1;
          break;
      }
  }
  if (sum == 0)
      cout << "tub son."<<endl;

*/
/*
int a = 0, b = 1, keyingisi = 0, n;

    cout << "Son kirit: ";
    cin >> n;


    cout << "Fibonacci sonlari: " << a << ", " << b << ", ";

    keyingisi = a + b;

    while(keyingisi <= n) {
        cout << keyingisi << ", ";
        a = b;
        b = keyingisi;
        keyingisi = a + b;
    }
*/
///                        3 - DARS
/// Foydalanuvchi tomonidan sonlar kiritilaveradi. Bu jarayon
///musbat bo’lmagan son kiritilguncha davom etadi. Kiritilgan
///musbat sonlarning yig’indisini toping
/*
int a, sum = 0;
while(true){
    cout << "son kiriting :";
    cin >> a;
    if (a < 0)
        break;
    sum += a;
}
cout << "yigindisi = " << sum;
*/

/*
  cout << "\n\n Find the perfect numbers between 1 and 500:\n";
  cout << "------------------------------------------------\n";
  int i = 1, u = 1, sum = 0;
  cout << "\n The perfect numbers between 1 to 500 are: \n";
  while (i <= 500)
  {
    while (u <= 500)
    {
      if (u < i)
      {
        if (i % u == 0)
          sum = sum + u;
      }
      u++;
    }
    if (sum == i) {
      cout << i << "  " << "\n";
    }
    i++;
    u = 1;
    sum = 0;
  }
*/
/*
int a = 0, b = 1, keyingisi = 0, n;

    cout << "Son kirit: ";
    cin >> n;


    cout << "Fibonacci sonlari: " << a << ", " << b << ", ";

    keyingisi = a + b;

    while(keyingisi <= n) {
        cout << keyingisi << ", ";
        a = b;
        b= keyingisi;
        keyingisi =a + b;
    }
*/

/*
int a, b, c = 0;
cout << "son kiriting";
cin >> a;


while(b != 0){
    b /= 10;
    c++;
}
while(a > 0){
    b += a % 10*pow(10, c-- -1);
    a /= 10;
}
cout << "sonni teskarisi" << b << endl;

*/
/*
int a;
cout << "son kiriting";
cin >> a;
for(int i = 1; i < a; i++){

    for(int j = 0; j < a - i; j++){
            cout << " ";

}

int k = 1;

for(; k < i; k++){
    cout << k;
}

for(; k > 0; k--){
        cout << k;

}
cout << "\n";

}
*/
/*
int a;
cout << "son kiritng";
cin >> a;
if (a / 2){
    cout << ++a;
}
else if (a /! 2){
    cout << a++;
}
*/

/*
int a, b, c, d, e, musbat, manfiy;
cin >> a;
cin >> b;
cin >> c;
cin >> d;
cin >> e;
if (a < 0)
    manfiy++;

else if (a > 0)
    musbat++;

if (b < 0)
    manfiy++;

else if (b > 0)
    musbat++;

if(c < 0)
    manfiy++;

else if (c > 0)
    musbat++;

if (d < 0)
    manfiy++;

else if (d > 0)
    musbat++;

if(e < 0)
    manfiy++;

else if (e > 0)
    musbat++;

cout << "musbat sonlar:  " << musbat << endl;
cout << "manfiy sonlar:  " << manfiy << endl;
cout << "nollar:" <<  5 - manfiy - musbat;
*/


/**
int a;
cin >> a;
cout << ((a == 1) ? "31 kun" : "");
cout << ((a == 2) ? "28 kun" : "");
cout << ((a == 3) ? "31 kun" : "");
cout << ((a == 4) ? "30 kun" : "");
cout << ((a == 5) ? "31 kun" : "");
cout << ((a == 6) ? "30 kun" : "");
cout << ((a == 7) ? "31 kun" : "");
cout << ((a == 8) ? "31 kun" : "");
cout << ((a == 9) ? "30 kun" : "");
cout << ((a == 10) ? "31 kun" : "");
cout << ((a == 11) ? "30 kun" : "");
cout << ((a == 12) ? "31 kun" : "");
*/
/*
int a;
cin >> a;

switch(a){
case 1 :{
        cout << "31 kun";
        break;
    }
case 2 :{
        cout << "28 kun";
        break;
    }
case 3 :{
        cout << "31 kun";
        break;
    }
case 4 :{
        cout << "30 kun";
        break;
    }
case 5 :{
        cout << "31 kun";
        break;
    }
case 6 :{
        cout << "30 kun";
        break;
    }
case 7 :{
        cout << "31 kun";
        break;
    }
case 8 :{
        cout << "31 kun";
        break;
    }
case 9 :{
        cout << "30 kun";
        break;
    }
case 10 :{
        cout << "31 kun";
        break;
    }
case 11 :{
        cout << "30 kun";
        break;
    }
case 12 :{
        cout << "31 kun";
        break;
    }

}
*/

/*
int a, sum = 0;


while (true){
    cout << "son kiritng";
    cin >> a;

    if (a == 0)
        break;
    sum += a;

}
cout << sum;
*/

/*
int a, i = 1, sum = 0;
cout << "son kiritng";
cin >> a;

while(i <= a){
    if (a % i == 0)
        sum += i;
    i++;
}
cout << sum;
*/

/*
for (int number = 1;number <= 1000; number ++){
    int nbs = 0;
    for(int i = 1; i <= number/2; i++){
        if(number % i == 0)
            nbs += i;
    }
    if (nbs == number)
        cout << number << "\t";
}
*/

/*
int a;
cout << "Son kiriting : ";
cin >> a;
for(int i = 1; i < a; i++){

    for(int j = 0; j < a - i; j++){
            cout << " ";

}

int k = 1;

for(; k < i; k++){
    cout << k;
}

for(; k > 0; k--){
        cout << k;

}
cout << "\n";

}
*/

/**
int a = 0, sum = 0;

while(a <= 10){

    sum+=a;
    a++;

}
cout << sum;
*/

/**
int a;
cout << "son kiriting" << endl;
cin >> a;
int b = 1;
while(a < 10){
    cout << a << " * " << b << " = " << a*b <<endl;
    b++;

}
*/
/**
int a, b, i, sum = 0;

cin >> a;
cin >> b    5
55;

i = a + 1;

while (i < b){
    sum += i;
    i++;
}
cout << sum;
*/

/**

int a, sum = 0;

cin >> a;
while (){}

int b = a % 10;
int s = a / 10;


cout << "yigindisi" << " " << b + s<<  " " << "ga teng" << endl;



*/

/// //////////////////// UYGA VAZIFA

///k va n butun sonlari berilgan. k sonini n marta ekranga chiqaruvchi programma tuzilsin.
/**
int n, k, i;
cout << "K sonini kiriting: ";
cin >> k;
cout << "N somimi kiriting: ";
cin >> n;
for(i=0; i < n; i++)
cout << k << "\n";
*/


/// a va b butun sonlari berilgan (a<b). a va b sonlari orasidagi barcha sonlarni
///(a va b sonlarni ham) ekranga chiqaruvchi va chiqarilgan sonlarni sonini ham chiqaruvchi
///programma tuzilsin.
/**
    int a, b, i = 1, z;
    cin >> a;
    cin >> b;

    if (a > b) {
        z = a;
        a = b;
        b = z;
    }

    cout << a << endl;

    while (i <= b) {
        a = a + 1;

    if (a <= b) {
        cout << a << endl;
    }
    i = i + 1;
  }

*/


/**
int n, k, i;
cout << "K sonini kiriting: ";
cin >> k;
cout << "N somimi kiriting: ";
cin >> n;
for(i=0; i < n; i++)
cout << k << "\n";
*/
/**
int k, n, i = 1;
cin >> k;
cin >> n;
while(i <= n){
    cout << k << endl;
    i++;
}
*/

/**
int a, b, sum = 0;
cin >> a;
cin >> b;


int i = b - 1;
while(i > a){
    cout << i << endl;
    sum+=i;
    i--;

}

cout << sum;
*/

/**
float a;
cout << "narx kiritng" << endl;
cin >> a;
float i = 0.1;
while(i <= 1.1){
    cout << i <<"/n"<< i*a << endl;
    i+=0.1;
}
*/

/**
float a;
cin >> a;
float i = 1, s = 0;
while(i <= a){
    s+=(1/i);
    i+=1;
}
cout << s;
*/

/**
float a;
cin >> a;
float i = 1.1, sum = 0, j = -1;
a = 1 +a/10;
while(i <= a){
    sum+=(i*j);
    i+=0.1;
    j*=-1;
}
cout << sum << endl;
*/


/**
    int n;
    cout<<"n = ";cin>>n;
    int a = 0;
    float i = 1.2;
    float s = 1.1;

    while(a<n){
        s-=i;
        i+=0.1;
        s+=i;
        i+=0.1;
        a++;
    }
    cout<<s;
*/
/**
int a, b;
cin >> a;
cin >> b;
int i = a + b;
while (i < b) {
    cout << i;
    i++;
}
*/
/**
int a;
cin >> a;
for (int i = 1; i <= a/2; i++) {
    if (a % i == 0) {
        cout << i << endl;
    }
    cout << a << endl;
}
*/

/**

string s1 = "salom", s2 = "";
char c = 's';
    for(int i = 0; i < s1.length(); i++){
        s2.append(s1, i, 1);
    if(s1[i] == c)
        s2.append(s1, i, 1);
    }
cout << s2;

*/



/**
string s1, s2, s3;
getline(cin,s1);
getline(cin,s2);

int len1 = s1.length();
int len2 = s2.length();

if(len1 > len2){
    s3 = s2 + s1 + s2;
}
else{
    s3 = s1 + s2 + s1;
}
cout << s3;
*/

/**
string s1, s2, s3;
    getline(cin,s1);
    getline(cin,s2);
    int n1, n2;
    cin >> n1 >> n2;
    s3.append(s1, 0, n1);
    s3.append(s2, n1, n2);
    cout << s3;
*/


/**
string s1 = "salom dunyo nima gaplar", s2 = "dunyo";
    for(int i = 0; i > s1.length(); i++){
        if(s1[i] == s2.length()){
            cout << true;
        }
        else{
            cout << false;
        }
    }
*/

/**
string s1 = "qwertyuiQWERTYUI.";
    int katta = 0;
    int kichik = 0;
    for(int i = 0; i < s1.length(); i++){
        if(islower(s1[i])){
            kichik++;
        }
        if(isupper(s1[i])){
            katta++;
        }


    }
cout << katta << endl;
cout << kichik << endl;
}


*/



























































          return 0;

}















